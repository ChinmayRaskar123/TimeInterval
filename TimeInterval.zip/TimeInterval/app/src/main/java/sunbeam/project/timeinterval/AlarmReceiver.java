package sunbeam.project.timeinterval;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import sunbeam.project.timeinterval.MainActivity;

/**
 * Created by sunbeam on 27/9/17.
 */

public class AlarmReceiver extends BroadcastReceiver{


    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "ALARM", Toast.LENGTH_SHORT).show();

    }
}
