package sunbeam.project.timeinterval;


import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;


public class MainActivity extends Activity {

    private Button mPopUp;
    private PopupWindow popupWindow, popupWindowAgain;
    int time = 4000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPopUp = (Button) findViewById(R.id.popUpButton);
        mPopUp.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,AlarmReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),0,intent,0);
                AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+time,pendingIntent);
                callPop(v); // Just for implementation
            }
        });

    }



    public void callPop(View v) {


        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.mainLayout);

        LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View layout = inflater.inflate(R.layout.screenpopup,(ViewGroup)findViewById(R.id.popUpElement));
        View layout = inflater.inflate(R.layout.screenpopup, null);

        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.MATCH_PARENT;
        boolean focusable = true;

        popupWindow = new PopupWindow(layout, width, height, focusable);
        popupWindow.showAtLocation(linearLayout, Gravity.CENTER_HORIZONTAL, 0, 0);

        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                popupWindow.dismiss();
                callPopAgain();
                return true;
            }
        });
    }


    private  void callPopAgain(){
        LinearLayout linearLayoutAgain = (LinearLayout)findViewById(R.id.mainLayout);

        LayoutInflater inflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layoutAgain = inflater.inflate(R.layout.screenpopupagain,null);

        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.MATCH_PARENT;
        boolean focusable = true;

        popupWindowAgain = new PopupWindow(layoutAgain,width,height,focusable);
        popupWindowAgain.showAtLocation(linearLayoutAgain, Gravity.CENTER_HORIZONTAL,0,0);

        layoutAgain.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                finish();
                //startActivity(new Intent(MainActivity.this, WelcomeActivity.class));
                return true;
            }
        });
    }















/*        popupWindow = new PopupWindow(layout, 300, 370, true);
        popupWindow.showAtLocation(layout, Gravity.CENTER,0,0);
        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                popupWindow.dismiss();
                return true;
            }
        });
*/


//    startActivity(new Intent(MainActivity.this, WelcomeActivity.class));




}